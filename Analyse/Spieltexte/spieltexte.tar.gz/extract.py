import struct,sys,os
d=open(sys.argv[1],'rb').read(); n=struct.unpack('<I',d[:4])[0]
ents=[]
for i in range(n):
    e=d[4+i*20:4+i*20+20]; name=e[:14].split(b'\0')[0].decode('latin1'); off,fl=struct.unpack('<IH',e[14:])
    ents.append((name,off,fl))
base=2+n*20
offs=sorted(set(o for _,o,_ in ents))+[len(d)-base]
os.makedirs(sys.argv[2],exist_ok=True)
for name,off,fl in ents:
    nxt=min(o for o in offs if o>off) if any(o>off for o in offs) else len(d)-base
    open(os.path.join(sys.argv[2],name),'wb').write(d[base+off:base+nxt])
print(n,'Eintraege')
